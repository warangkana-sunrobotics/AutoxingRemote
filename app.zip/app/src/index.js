import express from 'express';
import WebSocket from 'ws';
import { Queue as QueueMQ, Worker, FlowProducer } from 'bullmq';
import { createBullBoard } from '@bull-board/api';
import { ExpressAdapter } from '@bull-board/express';
import { BullMQAdapter } from '@bull-board/api/bullMQAdapter';
import axios from 'axios';
import axiosRetry from 'axios-retry';

import logger from './logger.js';
import config from '../config.json' with { type: 'json' };

// =========================
// Configuration & Defaults
// =========================

const SERVER_IP = "192.168.1.130";

const REDIS_OPTIONS = { 
  port: 6379, 
  host: process.env.REDIS_HOST || 'redis', 
  password: '', tls: false 
};

const TIMEOUT_DURATION = Number(process.env.TIMEOUT_DURATION_MS) || 80_000; // ms
const ENABLE_WEBSOCKET_TOPICS = ['/planning_state', '/battery_state', '/tracked_pose', "/wheel_state"];
const IDLE_CHARGE_DELAY = 80 * 60 * 1000; // 80 minutes

const LOW_BATTERY = Number(process.env.LOW_BATTERY_PCT) || 45; // percent
const CRITICAL_BATTERY = Number(process.env.CRITICAL_BATTERY_PCT) || 15; // percent
const FULL_BATTERY = Number(process.env.FULL_BATTERY_PCT) || 90; // percent

const area = config.area || {};
const point = config.point || { workstation: [0, 0], standby: [0, 0, 0], safety_entry: [0, 0, 0], safety_exit: [0, 0, 0], A1: [0, 0, 0] };

// =========================
// State
// =========================
let dispatcherWorker;
const workers = {};
const robots = new Map(); // ip -> { status, job_count, ws?, timeoutId?, battery?, charging? }
const queues = {}; // Map ip -> QueueMQ
const pendingSignals = new Map(); // key => { resolve, reject, timeout }
const jobs_and_token = new Map(); // Map jobId -> { job, token, ip }
const robotsActiveJob = new Map(); // Map ip -> currentJobId

let businessQueue;
let flowProducer;

// =========================
// Axios retry
// =========================
try{
  axiosRetry(axios, {
    retries: 3,
    retryDelay: (retryCount, error) => {
      const delay = Math.min(1000 * 2 ** retryCount, 5000); // max 5s
      logger.warn(`[Axios-retry] Retry #${retryCount} in ${delay}ms - ${error.code || error.message}`);
      return delay;
    },
    retryCondition: (error) => true,
  });
}catch(err) {
  logger.error(`[Axios-retry] Initialization failed: ${err.message}`);
}

// =========================
// Utilities
// =========================
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms)); // t in ms

const ACTION_SUCCESS_MAP = {
  align_with_rack: "align_succeeded",
  to_unload_point: "unload_succeeded",
  standard: "move_succeeded",
  charge: "charge_succeeded"
};

async function computeJobCount(ip) {
  const q = queues[ip];
  if (!q) return 0;
  try {
    const [active, waiting, waitingChildren] = await Promise.all([
    q.getActiveCount(),
    q.getWaitingCount(),
    q.getWaitingChildrenCount()
  ]);
  const total = active + waiting + waitingChildren;
  logger.info(`[computeJobCount] ${ip} - task count: ${total}`);
  return total;
  } catch (err) {
    logger.error('[computeJobCount] failed:', err.message);
    return 0;
  }
}

function updateRobot(ip, updates) {
  const prev = robots.get(ip) || {};
  const merged = { ...prev, ...updates };
   // Start idle timer if robot is idle and no jobs
  if (merged.status === 'idle' && (!merged.job_count || merged.job_count === 0) && !merged.charging) {
    if (!merged.idleTimer) {
      merged.idleTimer = setTimeout(() => {
        const robot = robots.get(ip) || {};
        if (robot.status === 'idle' && (!robot.job_count || robot.job_count === 0)) {
          logger.info(`[Auto-charge] Robot ${ip} idle for ${IDLE_CHARGE_DELAY}ms. Moving to charger`);
          triggerCharge(ip);
        }
      }, IDLE_CHARGE_DELAY);
    }
  } else {
    // Clear idle timer if robot becomes busy or charging
    if (prev.idleTimer) {
      clearTimeout(prev.idleTimer);
      merged.idleTimer = null;
    }
  }

  robots.set(ip, merged);
}

function failJobByIp(ip, reason) {
  const jobId = robotsActiveJob.get(ip);
  if (!jobId) return;
  const stored = jobs_and_token.get(jobId);
  if (!stored) return;
  try {
    stored.job.moveToFailed(new Error(reason), stored.token, true).catch((err) => {
      logger.error(`[failJobByIp] moveToFailed error for ${jobId}: ${err.message}`);
    });
  } catch (err) {
    logger.error('[failJobByIp] - error:', err.message);
  } finally {
    jobs_and_token.delete(jobId);
    robotsActiveJob.delete(ip);
    updateRobot(ip, { status: 'idle', charging: false });
  }
}

function waitForSignal(ip, eventName, timeoutMs) {
  const key = `${ip}:${eventName}`;

  return new Promise((resolve, reject) => {
    if (pendingSignals.has(key)) {
      return reject(new Error(`[waitForSignal] Already waiting for ${key}`));
    }

    let timeout = null;
    if (timeoutMs && timeoutMs > 0) {
      timeout = setTimeout(() => {
        pendingSignals.delete(key);
        reject(new Error(`[waitForSignal] Timeout waiting for ${eventName} from ${ip}`));
      }, timeoutMs);
    }

    pendingSignals.set(key, {
      resolve: (data) => {
        if (timeout) clearTimeout(timeout);
        pendingSignals.delete(key);
        resolve(data);
      },
      reject: (err) => {
        if (timeout) clearTimeout(timeout);
        pendingSignals.delete(key);
        reject(err);
      },
      timeout
    });
  });
}

const sendPostRequest = async (workflow_data, ip) => {
  const { endpoint, payload,  } = workflow_data;
  const apiEndpoint = `http://${ip}:8090${endpoint}`;

  try {
    logger.info(`[sendPostRequest] sending request: ${apiEndpoint} type: ${payload.type}`);
    const response = await axios.post(apiEndpoint, payload, {headers: {'Content-Type': 'application/json' }});
    return response.data;
  } catch (err) {
      logger.error(`[sendPostRequest] Request failed after retries: ${err.message}`);
      throw err;
  }
};

// =========================
// Workflows
// =========================
const workflows = {
  inbound: {
    move_to_standby: { type: 'move', endpoint: '/chassis/moves', payload: { creator: 'Demo Server', type: 'standard', target_x: point.standby[0], target_y: point.standby[1], target_ori: point.standby[2] }, successful_message: 'move_succeeded' },
    wait_safety_exit: { type: 'wait', release_signal: 'safety_released' },
    move_to_safety_exit: { type: 'move', endpoint: '/chassis/moves', payload: { creator: 'Demo Server', type: 'standard', target_x: point.safety_exit[0], target_y: point.safety_exit[1] }, successful_message: 'move_succeeded',plc_callback: { task_type: 'move_to_safety_exit', value: 1} },
    wait_unload: { type: 'wait', release_signal: 'holding_released' },
    move_to_inbound_unload: { type: 'move', endpoint: '/chassis/moves', payload: { creator: 'Demo Server', type: 'standard', target_x: point.in_outbound[0], target_y: point.in_outbound[1], target_ori: point.in_outbound[2] }, successful_message: 'move_succeeded',plc_callback: { task_type: 'move_to_inbound_unload', value: 1} },
    wait_safety_entry: { type: 'wait', release_signal: 'safety_released' },
    move_to_safety_entry: { type: 'move', endpoint: '/chassis/moves', payload: { creator: 'Demo Server', type: 'standard', target_x: point.safety_entry[0], target_y: point.safety_entry[1] }, successful_message: 'move_succeeded', plc_callback: { task_type: 'move_to_safety_entry', value: 1} },
    wait_worker: { type: 'wait', release_signal: 'holding_released' },
    move_to_workstation: { type: 'move', endpoint: '/chassis/moves', payload: { creator: 'Demo Server', type: 'standard', target_x: point.workstation[0], target_y: point.workstation[1], target_ori: point.workstation[2] }, successful_message: 'move_succeeded', plc_callback: { task_type: 'move_to_workstation', value: 1} }
  },
  outbound: {
    move_to_standby: { type: 'move', endpoint: '/chassis/moves', payload: { creator: 'Demo Server', type: 'standard', target_x: point.standby[0], target_y: point.standby[1], target_ori: point.standby[2] }, successful_message: 'move_succeeded' },
    wait_worker: { type: 'wait', release_signal: 'holding_released' },
    move_to_workstation: { type: 'move', endpoint: '/chassis/moves', payload: { creator: 'Demo Server', type: 'standard', target_x: point.workstation[0], target_y: point.workstation[1], target_ori: point.workstation[2] }, successful_message: 'move_succeeded', plc_callback: { task_type: 'move_to_workstation', value: 1} },
    wait_safety_exit: { type: 'wait', release_signal: 'safety_released' },
    move_to_safety_exit: { type: 'move', endpoint: '/chassis/moves', payload: { creator: 'Demo Server', type: 'standard', target_x: point.safety_exit[0], target_y: point.safety_exit[1] }, successful_message: 'move_succeeded', plc_callback: { task_type: 'move_to_safety_exit', value: 1} },
    wait_retreive: { type: 'wait', release_signal: 'holding_released' },
    move_to_outbound_retrieve: { type: 'move', endpoint: '/chassis/moves', payload: { creator: 'Demo Server', type: 'standard', target_x: point.in_outbound[0], target_y: point.in_outbound[1], target_ori: point.in_outbound[2] }, successful_message: 'move_succeeded', plc_callback: { task_type: 'move_to_outbound_retrieve', value: 1}  },
    wait_safety_entry: { type: 'wait', release_signal: 'safety_released' },
    move_to_safety_entry: { type: 'move', endpoint: '/chassis/moves', payload: { creator: 'Demo Server', type: 'standard',  target_x: point.safety_entry[0], target_y: point.safety_entry[1] }, successful_message: 'move_succeeded', plc_callback: { task_type: 'move_to_safety_entry', value: 1} },
  },
  dockCharger: {
    move_to_charger: { type: 'move', endpoint: '/chassis/moves', payload: { creator: 'Demo Server', type: 'charge', target_x: -1.4, target_y: 3.8, charge_retry_count : 3 }, successful_message: 'charge_succeeded' }
  },
  // For PLC manual troubleshooting.
  manual_out_of_safety_area: {
    move_to_safety_out_standby: { type: 'move', endpoint: '/chassis/moves', payload: { creator: 'Demo Server', type: 'standard', target_x: point.safety_entry[0], target_y: point.safety_entry[1], target_ori: 1.57 }, successful_message: 'move_succeeded' },
    wait_safety_exit: { type: 'wait', release_signal: 'safety_released' },
    move_to_safety_exit: { type: 'move', endpoint: '/chassis/moves', payload: { creator: 'Demo Server', type: 'standard', target_x: point.safety_exit[0], target_y: point.safety_exit[1] }, successful_message: 'move_succeeded', plc_callback: { task_type: 'move_to_safety_exit', value: 1} },
  },
  manual_into_safety_area: {
    move_to_safety_in_standby: { type: 'move', endpoint: '/chassis/moves', payload: { creator: 'Demo Server', type: 'standard', target_x: point.safety_exit[0], target_y: point.safety_exit[1], target_ori: -1.57 }, successful_message: 'move_succeeded' },
    wait_safety_entry: { type: 'wait', release_signal: 'safety_released' },
    move_to_safety_entry: { type: 'move', endpoint: '/chassis/moves', payload: { creator: 'Demo Server', type: 'standard',  target_x: point.safety_entry[0], target_y: point.safety_entry[1] }, successful_message: 'move_succeeded', plc_callback: { task_type: 'move_to_safety_entry', value: 1} }
  },
  manual_to_standby: {
    move_to_standby: { type: 'move', endpoint: '/chassis/moves', payload: { creator: 'Demo Server', type: 'standard', target_x: point.standby[0], target_y: point.standby[1], target_ori: point.standby[2] }, successful_message: 'move_succeeded' },
  },
  manual_to_workstation: {
    move_to_workstation: { type: 'move', endpoint: '/chassis/moves', payload: { creator: 'Demo Server', type: 'standard', target_x: point.workstation[0], target_y: point.workstation[1], target_ori: point.workstation[2] }, successful_message: 'move_succeeded', plc_callback: { task_type: 'move_to_workstation', value: 1} }
  },
  manual_to_inbound_unload: {
    move_to_inbound_unload: { type: 'move', endpoint: '/chassis/moves', payload: { creator: 'Demo Server', type: 'standard', target_x: point.in_outbound[0], target_y: point.in_outbound[1], target_ori: point.in_outbound[2] }, successful_message: 'move_succeeded',plc_callback: { task_type: 'move_to_inbound_unload', value: 1} },
  },
  manual_to_outbound_retrieve: {
    move_to_outbound_retrieve: { type: 'move', endpoint: '/chassis/moves', payload: { creator: 'Demo Server', type: 'standard', target_x: point.in_outbound[0], target_y: point.in_outbound[1], target_ori: point.in_outbound[2] }, successful_message: 'move_succeeded', plc_callback: { task_type: 'move_to_outbound_retrieve', value: 1}  },
  }
};

function createJobNode(ip, name, stepData) {
  return { name, queueName: ip, data: { workflow_data: stepData } };
}

function buildFlowFromWorkflow(ip, workflowKey) {
  const wf = workflows[workflowKey];
  if (!wf) throw new Error('Workflow not found: ' + workflowKey);
  const names = Object.keys(wf);

  function chain(i) {
    if (i >= names.length) return null;
      const node = createJobNode(ip, names[i], wf[names[i]]);
      const child = chain(i + 1);
    if (child) node.children = [child];
      return node;
  }
  return chain(0);
}

// =========================
// Battery management
// =========================
async function evaluateBattery(ip, pct) {
  const robot = robots.get(ip) || {};
  updateRobot(ip, { battery: pct });

  // If already charging
  if (robot.status === 'charging') {
    if (pct >= LOW_BATTERY) {
      logger.info(`[Battery] Robot ${ip} charged to ${pct}% - resuming`);
      updateRobot(ip, { status: 'idle', charging: false });
    }
    return;
  }

  if (pct <= CRITICAL_BATTERY) {
    logger.warn(`[Battery] CRITICAL battery level ${pct}% for ${ip}`);
    await triggerCharge(ip, true);
    return;
  }

  if (pct <= LOW_BATTERY) {
    updateRobot(ip, { status: 'charging_needed' });
    if ((robot.status === 'idle' || !robot.status) && !robot.charging) {
      await triggerCharge(ip, false);
    }
    return;
  }
}

async function triggerCharge(ip, force = false) {
  const robot = robots.get(ip) || {};
  if (robot.charging) return;

  logger.info(`[Charge] Scheduling charging workflow for ${ip} (force=${force})`);
  updateRobot(ip, { status: 'charging', charging: true });

  if (force && robotsActiveJob.has(ip)) {
    failJobByIp(ip, 'Battery critical, charging required');
  }

  try{
    const flowJob = buildFlowFromWorkflow(ip, 'dockCharger');
    await flowProducer.add(flowJob);
  }catch( err ){
    logger.error(`[Charge] failed to enqueue charging flow for ${ip}: ${err.message}`);
  }
}

// =========================
// Helper - wait for available robot
// =========================
function waitForAvailableRobot() {
  return new Promise((resolve) => {
    const interval = setInterval(() => {
      const available = [...robots.entries()].filter(([ip, r]) =>
        r.status === 'idle' && !r.charging && (!r.battery || r.battery > LOW_BATTERY)
      );

      if (available.length > 0) {
        clearInterval(interval);
        resolve(available);
      }
    }, 2000); // check every 2 sec
  });
}

// =========================
// Dispatcher worker
// =========================
function createDispatcher() {
  dispatcherWorker  = new Worker('dispatcher', async (job) => {
      const { order_type } = job.data;

      // Check immediately first
      let available = [...robots.entries()].filter(([ip, r]) =>
        r.status === 'idle' && !r.charging && (!r.battery || r.battery > LOW_BATTERY)
      );

      // IF NO ROBOT AVAILABLE - WAIT HERE
      if (available.length === 0) {
        logger.warn(`[DISPATCHER] No robots available - waiting...`);
        available = await waitForAvailableRobot();
      }

      // Choose robot with lowest job_count
      const [ip] = available.reduce((least, current) =>
        current[1].job_count < least[1].job_count ? current : least
      );

      const flowJob = buildFlowFromWorkflow(ip, order_type);
      await flowProducer.add(flowJob);

      const job_count = await computeJobCount(ip);
      updateRobot(ip, { job_count });

      logger.info(`[DISPATCHER] Assigned ${order_type} to robot ${ip}`);
      return { assignedRobot: ip };
    }, { connection: REDIS_OPTIONS }
  );

  dispatcherWorker.on('failed', (job, err) => {
    logger.warn('[DISPATCHER] job failed', job.id, err?.message || err);
  });

  return dispatcherWorker;
}

// =========================
// Worker creation per robot
// =========================
function createWorker(queueName) {
  const worker = new Worker( queueName, async (job, token) => {
      const { workflow_data } = job.data;

      // Track job
      jobs_and_token.set(job.id, { job, token, ip: queueName });
      robotsActiveJob.set(queueName, job.id);
      updateRobot(queueName, { status: 'working' });

      try {
        // Wait if robot is charging or requires charging
        let robot = robots.get(queueName) || {};
        // Polling loop: wait until robot not charging and not charging_needed
        while (robot.status === 'charging' || robot.status === 'charging_needed') {
          logger.info(`[WORKER] - ${queueName} - robot is charging/delayed. Pausing job ${job.id}`);
          await sleep(5000);
          robot = robots.get(queueName) || {};
        }

        // If the step is a move
        if (workflow_data && workflow_data.type === 'move') {
          logger.info(`[WORKER] waiting for MOVE signal: ${workflow_data.successful_message}`);
          // send request to robot service if endpoint specified
          try {
            if (workflow_data.endpoint) {
              await sendPostRequest(workflow_data, queueName);
            }
          } catch (e) {
            logger.warn(`[WORKER] sendPostRequest failed for job ${job.id} on ${queueName}: ${e.message}`);
            // continue — robot may still emit move signals
          }

          await waitForSignal(queueName, workflow_data.successful_message, TIMEOUT_DURATION);

          // callback to external PLC service (as original)
          if(workflow_data.plc_callback){
            try {
              const { task_type, value } = workflow_data.plc_callback;

              logger.info(`[WORKER] sending PLC POST request to http://${SERVER_IP}:5000/plc/writeTask with task_type of ${job.name}`)
              await axios.post(`http://${SERVER_IP}:5000/plc/writeTask`, 
                  { task_type, value }, 
                  { headers: { 'Content-Type': 'application/json' }}
              );
                logger.info(`[WORKER] POST Complete to PLC service (${job.name})`)
            } catch (e) {
              logger.warn(`[WORKER] PLC callback failed for ${job.name}<${job.id}>: ${e.message}`);
            }
          }
        }

        // If waiting step
        if (workflow_data && workflow_data.type === 'wait') {
          logger.info(`[WORKER] waiting for WAIT signal: ${workflow_data.release_signal}`);
          await waitForSignal(queueName, workflow_data.release_signal, 0);
        }

        // update job counts
        const job_count = await computeJobCount(queueName);
        updateRobot(queueName, { status: 'idle', job_count: Math.max(0, job_count - 1) });
        logger.info(`[WORKER] - ${queueName} - job: ${job.name} <${job.id}> is completed`);
        return { success: true, message: `Job ${job.id} completed on ${queueName}` };
      } catch (err) {
        try {
          logger.error(`[WORKER] - ${queueName} - error processing <${job.id}> error message: ${err.message}`);
          await job.moveToFailed(err, token, true);
        } catch (e) {
          logger.error(`[WORKER] - ${queueName} - error moving job <${job.id}> to failed:  ${e.message}`);
        }
        throw err;
      } finally {
        
        jobs_and_token.delete(job.id);
        if (robotsActiveJob.get(queueName) === job.id) robotsActiveJob.delete(queueName);
      }
    },
    { connection: REDIS_OPTIONS, lockDuration: 300000 }
  );

  worker.on('failed', (job, err) => {
    try {
      computeJobCount(queueName).then(count => updateRobot(queueName, { status: 'idle', job_count: Math.max(0, count), charging: false }));
      jobs_and_token.delete(job.id);
      if (robotsActiveJob.get(queueName) === job.id) robotsActiveJob.delete(queueName);
      logger.error(`[Worker] - ${queueName} - job <${job.id}> error message: ${err.message}`);
    } catch (e) {
      logger.error('[Worker] failed handler error:', e.message);
    }
  });

  return worker;
}

// =========================
// Geometry helpers
// =========================
function getBounds(rect) {
  const xs = rect.map(p => p[0]);
  const ys = rect.map(p => p[1]);

  return {
    minX: Math.min(...xs),
    maxX: Math.max(...xs),
    minY: Math.min(...ys),
    maxY: Math.max(...ys)
  };
}

function isPointInRectangle(pos, safety_area) {
  const rect = safety_area[0];
  const { minX, maxX, minY, maxY } = getBounds(rect);

  return (
    pos[0] >= minX &&
    pos[0] <= maxX &&
    pos[1] >= minY &&
    pos[1] <= maxY
  );
}

// =========================
// WebSocket connection per robot
// =========================
let lastEmergencyStop = null; // persists between messages

function connectWebSocket(ip) {
  const ws = new WebSocket(`ws://${ip}:8090/ws/v2/topics`);

  ws.on('open', async () => {
    try {
      ws.send(JSON.stringify({ disable_topic: ['/slam/state'] }));
      ws.send(JSON.stringify({ enable_topic: ENABLE_WEBSOCKET_TOPICS }));

      await axios.post( `http://${SERVER_IP}:5000/plc/writeTask`, { task_type: "robot_online_status", value: 1 });
      logger.info("[Websocket] POST to PLC service (robot_online: ONLINE)");

      logger.info(`[Websocket] ${ip} is connected`)
    } catch (err) {
      logger.error(`[Websocket] WS open send error for ${ip}:`, err.message);
    }

    const robot = robots.get(ip) || {};
    if (!robot.timeoutId) updateRobot(ip, { timeoutId: null });
  });

  ws.on('message', async (message) => {
    let data;
    try {
      data = JSON.parse(message);
    } catch (err) {
      return;
    }
    const { move_state, action_type, percentage, pos, topic, emergency_stop_pressed } = data;

    if (topic === "/wheel_state") {
      // First message → initialize, do not send
      if (lastEmergencyStop === null) {
        lastEmergencyStop = emergency_stop_pressed;
        return;
      }

      // Detect rising or falling edge
      if (emergency_stop_pressed !== lastEmergencyStop) {
        const value = emergency_stop_pressed ? 1 : 0;

        try {
            await axios.post(
              `http://${SERVER_IP}:5000/plc/writeTask`,
              { task_type: "robot_emergency_status", value }
            );

            logger.info(
              `[Websocket] Emergency stop ${emergency_stop_pressed ? "PRESSED" : "RELEASED"} - POST sent`
            );
        } catch (err) {
            logger.error(`[Websocket] Failed to send Emergency Stop status to PLC: ${err.message}`);
        }

        lastEmergencyStop = emergency_stop_pressed;
      }
    }

    if (topic === "/battery_state") {
      const pct = Math.round((percentage || 0) * 100);
      evaluateBattery(ip, pct).catch(e => logger.error('[battery evaluate error]', e.message));
    }
    
    // let eventName = null;
    if (topic === '/planning_state') {
      if (move_state === 'succeeded') {
        const eventName = ACTION_SUCCESS_MAP[action_type] || null;
        if (eventName) {
          const key = `${ip}:${eventName}`;
          const waiter = pendingSignals.get(key);
        if (waiter?.resolve) waiter.resolve(data);
        }
      }
      
      if (move_state === 'failed' || move_state === 'cancelled') {
        failJobByIp(ip, `Action ${action_type} ${move_state}`);
      }
    }
        
    if (topic === "/tracked_pose") {
      const isInside = isPointInRectangle(pos, area.safety_area_in_outbound);
      const robot = robots.get(ip) || {};

      // First time - set default
      if (robot.inInboundArea === undefined) {
          updateRobot(ip, { inInboundArea: isInside });
          return;
      }

      // ENTER event
      if (isInside && !robot.inInboundArea) {
          logger.info(`[Websocket] Robot - ${ip} - ENTERED inbound area`);
          updateRobot(ip, { inInboundArea: isInside });
          try {
              await sleep(1000);
              await axios.post( `http://${SERVER_IP}:5000/plc/writeTask`, { task_type: "robot_in_safety_area", value: 1 });
              logger.info("[Websocket] POST to PLC service (enter)");
          } catch (err) {
              logger.error("[Websocket] POST to PLC service (enter) failed: ", err.message);
          }
      }

      // EXIT event
      if (!isInside && robot.inInboundArea) {
          logger.info(`[Websocket] Robot - ${ip} - EXIT inbound area`);
          updateRobot(ip, { inInboundArea: isInside });
          try {
              await sleep(1000);
              await axios.post( `http://${SERVER_IP}:5000/plc/writeTask`, { task_type: "robot_in_safety_area", value: 0 });
              logger.info("[Websocket] POST to PLC service (exit)");
          } catch (err) {
              logger.error("[Websocket] POST to PLC serice (exit) failed:", err.message);
          }
      }

      // Update state
      updateRobot(ip, { inInboundArea: isInside });
    }
  });

  ws.on('error', (error) => {
    logger.error(`[WebSocket] Error (${ip}):`, error.message);
    failJobByIp(ip, `WebSocket error: ${error.message}`);
    const robot = robots.get(ip) || {};
    if (robot.timeoutId) {
      clearTimeout(robot.timeoutId);
      updateRobot(ip, { timeoutId: null });
    }
    for (const [key, waiter] of pendingSignals) {
      if (key.startsWith(`${ip}:`)) {
        waiter.reject(new Error('Robot disconnected'));
      }
    }
  });

  ws.on('close', async () => {
    logger.warn(`WebSocket closed for ${ip}, reconnecting in 10s...`);
    const robot = robots.get(ip) || {};
    if (robot.timeoutId) {
      clearTimeout(robot.timeoutId);
      updateRobot(ip, { timeoutId: null });
    }
    updateRobot(ip, { ws: null });
    setTimeout(() => connectWebSocket(ip), 10000);

    for (const [key, waiter] of pendingSignals) {
      if (key.startsWith(`${ip}:`)) {
        waiter.reject(new Error('Robot disconnected'));
      }
    }

    await axios.post( `http://${SERVER_IP}:5000/plc/writeTask`, { task_type: "robot_online_status", value: 0 });
    logger.info("[Websocket] POST to PLC service (robot_online: OFFLINE)");
  });

  // store ws
  updateRobot(ip, { ws });
}

// =========================
// HTTP Server & Routes
// =========================
async function run() {
  flowProducer = new FlowProducer({ connection: REDIS_OPTIONS });
  businessQueue = new QueueMQ('dispatcher', { connection: REDIS_OPTIONS });

  const app = express();
  app.use(express.json());
  app.use('/static', express.static('images'));

  const serverAdapter = new ExpressAdapter();
  serverAdapter.setBasePath('/ui');

  const { addQueue } = createBullBoard({
    queues: [ new BullMQAdapter(businessQueue) ], 
    serverAdapter,
    options: {
      uiConfig: { 
        boardTitle: 'AMR Control System',
        boardLogo: { path: '/static/board-logo.png', width: '25px', height: 25 },
        favIcon: { default: '/static/icon.png' } 
      } 
    } 
  });
  app.use('/ui', serverAdapter.getRouter());

  // start dispatcher
  dispatcherWorker = createDispatcher();

  app.post('/add-task', async (req, res) => {
    try {
      const { order_type } = req.body;

      if (!order_type) return res.status(400).send({ error: 'order_type is required' });

      const wf = workflows[order_type];
      if (!wf) return res.status(403).send({error: `Workflow not found: ${order_type}`});

      await businessQueue.add('mission', { order_type }, { removeOnComplete: true });

      logger.info(`[add-task] task ${order_type} stored in business queue`);
      return res.send({ success: 1, message: 'Task queued' });
    } catch (error) {
      logger.error('[add-task] error:', error.message || error);
      return res.status(500).send({ error: error.message || error });
    }
  });

  app.post('/add-manual-task', async (req, res) => {
    try{
      const { order_type, robot_ip } = req.body;

      if (!order_type || !robot_ip) return res.status(400).send({ error: 'order_type and robot_ip are required' });

      if (!robots.has(robot_ip)) return res.status(404).send({ error: 'Robot not found'});

      const wf = workflows[order_type];
      if (!wf) return res.status(403).send({error: `Workflow not found: ${order_type}`});

      if (typeof order_type !== 'string' || !order_type.startsWith('manual')) {
        return res.status(400).send({ error: 'order_type must be manual' });
      }

      const robot = robots.get(robot_ip)
      const invalidWhenInside = [
        "manual_into_safety_area", 
        "manual_to_standby", 
        "manual_to_workstation"
      ];

      const invalidWhenOutside = [
        "manual_out_of_safety_area", 
        "manual_to_inbound_unload", 
        "manual_to_outbound_retrieve"
      ];

      const isInside = robot.inInboundArea == 1;

      if (isInside && invalidWhenInside.includes(order_type)) {
        return res.status(403).send({ error: "Action denied: Robot is inside the safety area" });
      }

      if (!isInside && invalidWhenOutside.includes(order_type)) {
        return res.status(403).send({ error: "Action denied: Robot is outside the safety area" });
      }

      const flowJob = buildFlowFromWorkflow(robot_ip, order_type);
      await flowProducer.add(flowJob);

      logger.info(`[add-manual-task] task ${order_type} added to robot-${robot_ip}`);
      return res.send({ success: 1, message: 'Task queued' });
    } catch (error) {
      logger.error('[add-manual-task] error:', error.message || error);
      return res.status(500).send({ error: error.message || error });
    }
  })

  app.post('/add-robots', async (req, res) => {
    const { ip } = req.body;
    if (!ip) return res.status(400).send({ error: 'IP address is required' });

    try {
      if (robots.has(ip)) return res.status(403).send({ message: `Robot ${ip} already exists` });

      connectWebSocket(ip);
      updateRobot(ip, { status: 'idle', job_count: 0, battery: 100, charging: false });

      queues[ip] = new QueueMQ(ip, { connection: REDIS_OPTIONS });
      addQueue(new BullMQAdapter(queues[ip]));
      workers[ip] = createWorker(ip);

      logger.info(`[add-robots] robot ip: ${ip} is added`);
      return res.status(200).send({ message: `robot ip: ${ip} is added successfully` });
    } catch (err) {
      logger.error('[add-robots] error:', err.message || err);
      return res.status(500).send({ error: err.message });
    }
  });

  app.post('/release-signal', (req, res) => {
    const { ip, signal } = req.body;
    if (!ip || !signal) return res.status(400).send({ error: 'ip and signal are required' });

    if (!robots.has(ip)) return res.status(404).send({ error: 'ip not availiable'});
 
    const key = `${ip}:${signal}`;
    const waiter = pendingSignals.get(key);
    if (!waiter){
      logger.error(`[release-signal] No pending ${signal} signal for this robot.`)
      return res.status(404).send({ error: `No pending ${signal} signal for this robot` });
      // return res.send({ success: 0 , error: `No ${signal} signal for this robot` });
    }

    logger.info(`[release-signal] ${signal} for robot ip: ${ip}`)
    waiter.resolve({ message: 'released' });
    return res.send({ success: 1 });
  });

  app.get('/get-job-tokens', (req, res) => {
    res.send({ jobs_and_token: Array.from(jobs_and_token.keys()) });
  });

  app.get('/get-pending-signal', (req, res) => {
    res.send({ pendingSignals: Array.from(pendingSignals.keys()) });
  });

  app.get('/robots-status', (req, res) => {
    try {
      const robotStatus = Array.from(robots.entries()).map(([ip, data]) => ({
        ip,
        status: data.status || 'unknown',
        job_count: data.job_count || 0,
        battery: data.battery ?? null,
        charging: data.charging || false,
        inInboundArea: data.inInboundArea ?? null
      }));

      res.send({ robots: robotStatus , robotsActiveJob: Array.from(robotsActiveJob.keys()) });
    } catch (err) {
      logger.error('[robots-status] error:', err.message);
      res.status(500).send({ error: err.message });
    }
  });

  app.post('/delete-all-job', async (req, res) => {
    try {
      // queueName is either "dispatcher" or robot's ip address
      const { queueName } = req.body;
      if (!queueName ) return res.status(400).send({ error: 'queueName is required' });

      if(queueName === "dispatcher"){
        logger.warn('[MANUAL DELETE] Stopping dispatcher worker');
        if (dispatcherWorker) {
          await dispatcherWorker.close(true);
        }
        logger.warn('[MANUAL DELETE] obliterating dispatcher worker');
        await businessQueue.obliterate({ force: true });

        logger.warn('[MANUAL DELETE] creating dispatcher worker');
        dispatcherWorker = createDispatcher();
      }else{
        const queue = queues[queueName];
        const worker = workers[queueName];

        if (!queue) return res.status(404).send({ error: 'Queue not found' });

        logger.warn(`[MANUAL DELETE] Stopping worker for ${queueName}`);

        const key_holding = `${queueName}:holding_released`;
        const waiter_holding = pendingSignals.get(key_holding);

        const key_safety = `${queueName}:safety_released`;
        const waiter_safety = pendingSignals.get(key_safety);

        if(waiter_holding){
          waiter_holding.resolve({ message: 'released' });
        }
        if(waiter_safety){
          waiter_safety.resolve({ message: 'released' })
        }

        if (worker){
          await worker.close();
          delete workers[queueName];
        } 
        await queue.obliterate({ force: true });
        // recreate worker after delete
        workers[queueName] = createWorker(queueName);

        updateRobot(queueName, { status: 'idle', charging: false });
      }
      logger.warn(`[MANUAL DELETE] Removed all job from ${queueName}`);
      res.send({ success: 1, message: `All job deleted from robot ${queueName}` });
    } catch (err) {
      logger.error('[delete-job] error:', err.message);
      res.status(500).send({ error: err.message });
    }
  });

  app.post('/delete-job', async (req, res) => {
    try {
      const { queueName, jobId } = req.body;
      if (!queueName || !jobId) return res.status(400).send({ error: 'queueName and jobId are required' });

      const queue = queues[queueName];
      if (!queue) return res.status(404).send({ error: `Queue not found for ${queueName}` });

      const job = await queue.getJob(jobId);
      if (!job) return res.status(404).send({ error: 'Job not found' });

      await job.remove();

      logger.warn(`[MANUAL DELETE] Job ${jobId} removed from ${queueName}`);
      res.send({ success: 1, message: `Job ${jobId} deleted from robot ${queueName}` });
    } catch (err) {
      logger.error('[delete-job] error:', err.message);
      res.status(500).send({ error: err.message });
    }
  });

  app.post('/complete-job', async (req, res) => {
    try {
      const { queueName, result = { forced: true } } = req.body;
      if (!queueName) return res.status(400).send({ error: 'queueName is required' });

      const jobId = robotsActiveJob.get(queueName);
      if (!jobId) return res.status(404).send({ error: 'No active job for this robot' });

      const stored = jobs_and_token.get(jobId);
      if (!stored) return res.status(404).send({ error: 'Job token missing' });

      await stored.job.moveToCompleted(result, stored.token, true);

      jobs_and_token.delete(jobId);
      robotsActiveJob.delete(queueName);

      updateRobot(queueName, { status: 'idle' });

      logger.warn(`[MANUAL COMPLETE] Job ${jobId} force-completed on ${queueName}`);
      res.send({ success: 1, message: `Job ${jobId} force-completed on ${queueName}`
      });

    } catch (err) {
      logger.error('[complete-job] error:', err.message);
      res.status(500).send({ error: err.message });
    }
  });

  const PORT = process.env.PORT || 9000;
  app.listen(PORT, () => {
    logger.info(`[Start] Robot management platform running on http://localhost:${PORT}/ui`);
    logger.info('[Start] Make sure Redis is running on port 6379 by default');
  });
} 

run().catch((e) => logger.error(e));
