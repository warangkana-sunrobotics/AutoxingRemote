// const { createLogger, format, transports } = require('winston');
import { createLogger, format, transports } from 'winston';
import DailyRotateFile from 'winston-daily-rotate-file';
import path from 'path'; 
// const DailyRotateFile = require('winston-daily-rotate-file');
// const path = require('path');

// Define log format
const logFormat = format.combine(
  format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
  format.printf(info => `${info.timestamp} [${info.level.toUpperCase()}]: ${info.message}`)
);

// Create a daily rotate transport
const rotateTransport = new DailyRotateFile({
  filename: path.join('./logs', 'rcs-%DATE%.log'),
  datePattern: 'YYYY-MM-DD',           // rotate daily
  zippedArchive: true,                 // compress old logs
  maxSize: '20m',                      // max file size before rotation
  maxFiles: '14d',                     // keep logs for 14 days
  level: 'info'
});

// Create Winston logger
const logger = createLogger({
  level: 'info',
  format: logFormat,
  transports: [
    rotateTransport,
    new transports.Console({
      format: format.combine(
        format.colorize(),
        format.printf(info => `${info.timestamp} [${info.level}]: ${info.message}`)
      )
    })
  ]
});

export default logger;