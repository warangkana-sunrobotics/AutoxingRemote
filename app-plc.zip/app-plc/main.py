from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from plc import PLC
from snap7.util import *
import requests
import threading
import time
import logging
import sys
import os
from datetime import datetime
from logging.handlers import RotatingFileHandler

logger = logging.getLogger("plc_service")

def setup_logging():
    """Configures logging for App and Uvicorn to write to file & console"""
    
    # 1. Create 'logs' directory if it doesn't exist
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)

    # 2. Generate Filename: logs/app-2025-12-22.log
    current_date = datetime.now().strftime("%Y-%m-%d")
    log_filename = os.path.join(log_dir, f"plc-{current_date}.log")
    
    # 3. Define Format
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    
    # 4. File Handler (Saves logs to 'plc_api.log', rotates at 5MB)
    file_handler = RotatingFileHandler(log_filename, maxBytes=5*1024*1024, backupCount=3)
    file_handler.setFormatter(formatter)
    file_handler.setLevel(logging.DEBUG) # Capture EVERYTHING in file
    
    # 5. Console Handler (Standard Output)
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    console_handler.setLevel(logging.INFO) # Keep console clean
    
    # 6. Configure App Logger
    logger.setLevel(logging.DEBUG)
    # Clear existing handlers to prevent duplicates if function is called twice
    if logger.hasHandlers():
        logger.handlers.clear()
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    
    # 7. [CRITICAL] Attach File Handler to Uvicorn Loggers
    # This makes Uvicorn write HTTP requests (GET/POST) to your log file too!
    logging.getLogger("uvicorn.access").addHandler(file_handler)
    logging.getLogger("uvicorn.error").addHandler(file_handler)

# Run setup immediately
setup_logging()

app = FastAPI(title="PLC REST API")

PLC_IP = "192.168.1.100"
RCS_IP = "192.168.1.130"
ROBOT_IP = "192.168.1.105"
WATCH_DB = 49
WATCH_START_BYTE = 0

plc = PLC(PLC_IP)

plc_lock = threading.RLock()

# ---------- MODELS ----------
class ReadRequest(BaseModel):
    db: int
    byte: int
    type: str  # bool | int | real
    bit: int | None = None


class WriteRequest(BaseModel):
    db: int
    byte: int
    type: str
    value: float | int | bool
    bit: int | None = None

class WriteTaskRequest(BaseModel):
    task_type: str
    value: int

last_value = None

DB_OFFSET_ARRAY = [0] * 16

TASKS_MAP = {
    "move_to_inbound_unload": 12,
    "move_to_outbound_retrieve": 14,
    "move_to_safety_entry": 16,
    "move_to_safety_exit": 18,
    "robot_in_safety_area": 20,
    "robot_online_status": 22,
    "robot_emergency_status": 24,
    "move_to_workstation": 30
}

# Keys are (DB_Byte_Index_Ignored, Byte_Offset)
INT_ACTIONS = {
    (0, 0): { # PLC Write offset
        "name": "inbound_unload_finish_status",
        "apiEndpoint": f"http://{RCS_IP}:9000/release-signal",
        "edge": "rising",
        "data" : {
            "ip" : ROBOT_IP,
            "signal" : "holding_released"
        }
    },
    (0, 2): {
        "name": "outbound_retreive_finish_status",
        "apiEndpoint": f"http://{RCS_IP}:9000/release-signal",
        "edge": "rising",
        "data" : {
            "ip" : ROBOT_IP,
            "signal" : "holding_released"
        }
    },
    (0, 4): {
        "name": "safety_light_curtain_status",
        "apiEndpoint": f"http://{RCS_IP}:9000/release-signal",
        "edge": "falling",
        "data" : {
            "ip" : ROBOT_IP,
            "signal" : "safety_released"
        }
    },
    (0, 6): {
        "name": "create_inbound_task",
        "apiEndpoint": f"http://{RCS_IP}:9000/add-task",
        "edge": "rising",
        "data" : {
            "order_type" : "inbound"
        }
    },
    (0, 8): {
        "name": "create_outbound_task",
        "apiEndpoint": f"http://{RCS_IP}:9000/add-task",
        "edge": "rising",
        "data" : {
            "order_type" : "outbound"
        }
    },
    (0, 10): {
        "name": "operator_finish",
        "apiEndpoint": f"http://{RCS_IP}:9000/release-signal",
        "edge": "rising",
        "data" : {
            "ip" : ROBOT_IP,
            "signal" : "holding_released"
        }
    },
    (0, 12): {   # PLC Read offset
        "name": "move_to_inbound_unload",
        "apiEndpoint": "",
        "edge": "null",
        "data" : {
            "test" : "test"
        }
    },
    (0, 14): {
        "name": "move_to_outbound_retrieve",
        "apiEndpoint": "",
        "edge": "null",
        "data" : {
            "test" : "test"
        }
    },
    (0, 16): {
        "name": "move_to_safety_entry",
        "apiEndpoint": "",
        "edge": "null",
        "data" : {
            "test" : "test"
        }
    },
    (0, 18): {
        "name": "move_to_safety_exit",
        "apiEndpoint": "",
        "edge": "null",
        "data" : {
            "test" : "test"
        }
    },
    (0, 20): {
        "name": "robot_in_safety_area",
        "apiEndpoint": "",
        "edge": "both",
        "data" : {
            "test" : "test"
        }
    },
    (0, 22): {
        "name": "robot_online_status",
        "apiEndpoint": "",
        "edge": "null",
        "data" : {
            "test" : "test"
        }
    },
    (0, 24): {
        "name": "robot_emergency_status",
        "apiEndpoint": "",
        "edge": "null",
        "data" : {
            "test" : "test"
        }
    },
    (0, 26): {
        "name": "plc_emergency_stop",
        "apiEndpoint": f"http://{ROBOT_IP}:8090/chassis/moves/current",
        "edge": "rising",
        "data" : {
            "state": "cancelled"
        }
    },
    (0, 28): { 
        "name": "robot_manual",
        "edge": "both",
    },
    (0, 30): {
        "name": "move_to_workstation",
        "apiEndpoint": "",
        "edge": "null",
        "data" : {
            "test" : "test"
        }
    },
    (0, 32): {
        "name": "delete_all_job",
        "apiEndpoint": f"http://{RCS_IP}:9000/delete-all-job",
        "edge": "rising",
        "data" : {
            "queueName" : "192.168.1.105" 
        }
    }
}
    

last_state = {}

def trigger_action(cfg, current):
    
    try:
        if cfg["name"] == "robot_manual":
            # Map the integer 'current' value to the specific order string
            manual_orders = {
                1: "manual_out_of_safety_area",
                2: "manual_into_safety_area",
                3: "manual_to_standby",
                4: "manual_to_workstation",
                5: "manual_to_inbound_unload",
                6: "manual_to_outbound_retrieve",
            }
            
            order_type = manual_orders.get(current)

            if order_type:
                try:
                    url = f"http://{RCS_IP}:9000/add-manual-task"
                    payload = {"order_type": order_type, "robot_ip": ROBOT_IP}
                    
                    logger.info(f"   [POST] Attempting {url} | {order_type}")
                    res = requests.post(url, json=payload, timeout=3)
                    logger.info(f"   [POST] Response {res.status_code} : {url} | order_type: {order_type}")
                except requests.exceptions.Timeout:
                    logger.error(f"   [POST] Failed: Timeout")
                except Exception as e:
                    logger.error(f"   [POST] Failed: {e}")
                return
            else:
                logger.info(f"   [PLC] robot_manual reset to {current}. No action taken.")
                return
    
        if(cfg["name"] == "plc_emergency_stop"):
            try:
                url = cfg['apiEndpoint']
                payload = cfg['data']
                
                logger.info(f"   [POST] Attempting {url} | Payload: {payload}")
                res = requests.patch(url, json=payload, timeout=3)
                logger.info(f"   [POST] Response {res.status_code} : {url}")
            except requests.exceptions.Timeout:
                logger.error(f"   [POST] Failed: Timeout")
            except Exception as e:
                logger.error(f"   [POST] Failed: {e}")
            return

        if(cfg["name"] == "robot_in_safety_area" and current == 1):
            with plc_lock:
                zero_data = bytearray(2) 
                plc.write_db(WATCH_DB, 16, zero_data)
            logger.info("reset move_to_safety_entry")
            return
        
        if(cfg["name"] == "robot_in_safety_area" and current == 0):
            with plc_lock:
                zero_data = bytearray(2) 
                plc.write_db(WATCH_DB, 18, zero_data)
            logger.info("reset move_to_safety_exit")
            return
        
        if cfg["apiEndpoint"]:
            try:
                url = cfg['apiEndpoint']
                payload = cfg['data']

                logger.info(f"   [POST] Attempting {url} | Payload: {payload}")
                res = requests.post(url, json=payload, timeout=3)
                logger.info(f"   [POST] Response {res.status_code} : {url} | Payload: {payload}")
            except requests.exceptions.Timeout:
                logger.error(f"   [POST] Failed: Timeout")
            except Exception as e:
                logger.error(f"   [POST] Failed: {e}")


        if(cfg["name"] == "create_inbound_task"):
            with plc_lock:
                zero_data = bytearray(2) 
                plc.write_db(WATCH_DB, 6, zero_data)
            logger.info("reset create_inbound_task")
        
        if(cfg["name"] == "create_outbound_task"):
            with plc_lock:
                zero_data = bytearray(2) 
                plc.write_db(WATCH_DB, 8, zero_data)
            logger.info("reset create_outbound_task")      

    except Exception as e:
        logger.error(f"POST failed: {e}")

def plc_int_watcher():
    global last_state

    with plc_lock:
        try:
            if not plc.is_connected():
                plc.connect()
        except Exception as e:
            logger.error(f"Startup connection failed: {e}")

    logger.info("--- PLC Watcher Started ---")
    
    while True:
        try:
                with plc_lock:
                    connected = plc.is_connected()
                    if connected:
                        # Read all data while we have the lock
                        data = plc.read_db(WATCH_DB, WATCH_START_BYTE, 34)
                
                # If not connected, skip this iteration
                if not connected:
                    time.sleep(1)
                    continue

                for (_, offset), cfg in INT_ACTIONS.items():
                    # 'offset' corresponds to the byte index in the buffer
                    current = get_int(data, offset)
                    previous = last_state.get(offset, 0) # Use offset as key for simplicity
                    # print(f"DB{WATCH_DB}.DBX0.{offset} {cfg['name']} = {current}")

                    # Only process if value CHANGED
                    if current != previous:
                        logger.info(f"Change detected on {cfg['name']} (Offset {offset}): {previous} -> {current}")
                        array_index = offset//2
                        if 0 <= array_index < len(DB_OFFSET_ARRAY):
                            DB_OFFSET_ARRAY[array_index] = current

                        edge = cfg.get("edge", "rising")
                        
                        if edge == "rising" and previous == 0 and current == 1:
                            trigger_action(cfg, current)
                        elif edge == "falling" and previous == 1 and current == 0:
                            trigger_action(cfg, current)
                        elif edge == "both":
                            trigger_action(cfg, current)

                        last_state[offset] = current
                # print("--------------------------")

        except Exception as e:
            # Snap7 usually raises RuntimeError for connection issues
            error_msg = str(e)
            logger.error(f"PLC Loop Error:: {error_msg}")
            
            if "recv TCP" in error_msg or "timed out" in error_msg or "ISO" in error_msg:
                logger.error("!!! CRITICAL: Socket desynchronized. Forcing Hard Reconnect. !!!")
                with plc_lock:
                    try:
                        plc.disconnect() # Force close the socket
                    except Exception as disconnect_err:
                        logger.error(f"Failed to disconnect cleanly: {disconnect_err}")
                time.sleep(2) # Breathe before retrying
            
        time.sleep(1)

def plc_watchdog():
    while True:
        with plc_lock:
            try:
                if not plc.is_connected():
                    # print("PLC disconnected, trying reconnect...")
                    plc.connect()
                    logger.info("PLC Reconnected successfully")
            except Exception as e:
                logger.error(f"Watchdog connection failed: {e}")
        
        time.sleep(5)

@app.on_event("startup")
def startup_event():
    threading.Thread(target=plc_int_watcher, daemon=True).start()
    threading.Thread(target=plc_watchdog, daemon=True).start()

# ---------- READ  ----------
@app.get("/plc/getDBData")
def getDBData():
    return { "data": DB_OFFSET_ARRAY }

# ---------- WRITE ----------
@app.post("/plc/directWrite")
def write_plc(req: WriteRequest):
    try:

        if req.type == "bool":
            with plc_lock:
                data = plc.read_db(req.db, req.byte, 1)
                set_bool(data, 0, req.bit, req.value)
                plc.write_db(req.db, req.byte, data)

        elif req.type == "int":
            with plc_lock:
                data = plc.read_db(req.db, req.byte, 2)
                set_int(data, 0, req.value)
                plc.write_db(req.db, req.byte, data)

        elif req.type == "real":
            with plc_lock:
                data = bytearray(4)
                set_real(data, 0, float(req.value))
                plc.write_db(req.db, req.byte, data)

        else:
            raise HTTPException(400, "Unsupported data type")

        return {"status": "ok"}

    except Exception as e:
        raise HTTPException(500, str(e))

@app.post("/plc/writeTask")
def write_plc(req: WriteTaskRequest):
    try:
        offset = TASKS_MAP.get(req.task_type)
        if offset == None:
            raise HTTPException(400, "Invalid task type")
        with plc_lock:
            data = plc.read_db(49, offset, 2)  
            set_int(data, 0, req.value)
            plc.write_db(49, offset, data)

        logger.info(f"setting DB{WATCH_DB}.DBX0.{offset} {req.task_type} to {req.value}")
        return {"status": "ok"}

    except Exception as e:
        logger.error(f"Error occured in ")
        raise HTTPException(500, str(e))
