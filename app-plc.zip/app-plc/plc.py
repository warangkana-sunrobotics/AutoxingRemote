import snap7
import threading


class PLC:
    def __init__(self, ip, rack=0, slot=1, retry_interval=3):
        self.ip = ip
        self.rack = rack
        self.slot = slot
        self.retry_interval = retry_interval

        self.client = snap7.client.Client()
        self._lock = threading.Lock()
        self._connected = False

    def connect(self):
        with self._lock:
            if self.client.get_connected():
                self._connected = True
                return True

            try:
                self.client.connect(self.ip, self.rack, self.slot)
                self._connected = self.client.get_connected()
                return self._connected
            except Exception:
                self._connected = False
                return False

    def ensure_connection(self):
        """Call this before every PLC operation"""
        if not self.client.get_connected():
            return self.connect()
        return True

    def disconnect(self):
        with self._lock:
            try:
                self.client.disconnect()
            finally:
                self._connected = False

    def is_connected(self):
        return self.client.get_connected()

    # -------- SAFE READ / WRITE --------
    def read_db(self, db, start, size):
        if not self.ensure_connection():
            raise ConnectionError("PLC not connected")

        try:
            return self.client.db_read(db, start, size)
        except Exception:
            # connection dropped during read → force reconnect next time
            self._connected = False
            raise

    def write_db(self, db, start, data):
        if not self.ensure_connection():
            raise ConnectionError("PLC not connected")

        try:
            self.client.db_write(db, start, data)
        except Exception:
            self._connected = False
            raise
