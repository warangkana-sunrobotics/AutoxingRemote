# start up command
uvicorn main:app --host 0.0.0.0 --port 5000

# Swagger
http://192.168.1.69:8000/docs